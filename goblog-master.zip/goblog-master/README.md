# goblog
Micro blogging done with Golang

1. [Capítulo 1: ¡Hola Mundo!](https://www.cibernomadas.es/go-con-gin-el-mega-tutorial/)
1. [Capítulo 2: Plantillas](https://www.cibernomadas.es/go-con-gin-el-mega-tutorial-ii/)
1. [Capítulo 3: Formularios web](https://www.cibernomadas.es/go-con-gin-el-mega-tutorial-iii/)
